#include <stdio.h>
void mostrarInformacion(float velocidad, float *punteroVelocidad);


void mostrarInformacion(float velocidad, float *punteroVelocidad)
{
    printf("Velocidad actual: %.3f km/h\n", velocidad);
    printf("Dirección de memoria de velocidad: %p\n", &velocidad);
    printf("Velocidad apuntada por puntero: %.3f km/h\n", *punteroVelocidad);
    printf("Dirección de memoria almacenada en puntero: %p\n", punteroVelocidad);
}
int main()
{
    
    float  velocidad=123.123;
    float  *punteroVelocidad=&velocidad;
    mostrarInformacion(velocidad,punteroVelocidad);
    return 0;
}