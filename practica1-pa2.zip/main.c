
#include <stdio.h>
#define size 2
int main()
{
    char c;
    int x;
    double y;
    int Arreglo[size];
    printf("PRACTICA 1\n");
    printf("TIPOS DE DATOS\n");
    printf("CHAR\n");
    printf("El tamaño en bytes de una variable char es: %d\n",sizeof(c));
    printf("El tamaño en bits de una variable char es: %d\n",sizeof(c)*8);
    printf("El tamaño en nibbles de una variable char es: %d\n",sizeof(c)*2);
    printf("ENTERO\n");
    printf("El tamaño en bytes de una variable int es: %d\n",sizeof(x));
    printf("El tamaño en bits de una variable int es: %d\n",sizeof(x)*8);
    printf("El tamaño en nibbles de una variable int es: %d\n",sizeof(x)*2);
    printf("DOUBLE\n");
    printf("El tamaño en bytes de una variable double es: %d\n",sizeof(y));
    printf("El tamaño en bits de una variable double es: %d\n",sizeof(y)*8);
    printf("El tamaño en nibbles de una variable double es: %d\n",sizeof(y)*2);
    printf("ARREGLO\n");
    printf("El tamaño en bytes de un arreglo es: %d\n",sizeof(Arreglo));
    printf("El tamaño en bits de unarreglo es: %d\n",sizeof(Arreglo)*8);
    printf("El tamaño en nibbles de unarreglo es: %d\n",sizeof(Arreglo)*2);
    return 0;
    
}
