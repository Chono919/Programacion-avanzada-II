#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int opcion;
int lectura;
#define NUM_NEUMATICOS 4

void readPresion(int * arregloPresiones)
    {
    int i;
    srand(time(NULL));
        for(i=0;i<NUM_NEUMATICOS;i++)
             arregloPresiones[i]=rand() % 50 + 20;
    }
int main()
{
    lectura=0;
    int presion_neumaticos[NUM_NEUMATICOS];
    int i;
    readPresion(presion_neumaticos);
    int reset;
    while(reset==0)
    {
        printf("OPCION 1: LECTURA\nOPCION 2: ANALIZAR\nOPCION 3:IMPRIMIR\n");
        scanf("%d",&opcion);
        if(opcion==1)//Error si no se realiza la Lectura
            {
            system("clear");
            lectura=1;
            printf("Lectura exitosa\n");
            }
        else if(opcion==2)
            {
            if(lectura==1)
            {
                system("clear");
                printf("Analisis realizado exitosamente\n");
               for(i=0;i<NUM_NEUMATICOS;i++)
                    {
                        if(presion_neumaticos[i]>50)
                        {
                            presion_neumaticos[i]=presion_neumaticos[i]+1000;
                        }
                    }
            }
            else
                {
                system("clear");
                printf("Error, no se ha realizado la lectura\n");
                }
            }
            
        else if(opcion==3)
            {
                if (lectura==1)
                    {
                    system("clear");
                    printf("Presion de Neumaticos:\n");
                    for(i=0;i<NUM_NEUMATICOS;i++)
                        if(presion_neumaticos[i]<999)
                            printf("Neumatico %d: %d PSI\n",i+1,presion_neumaticos[i]);
                    else
                        printf("Neumatico %d: %d PSI: PRESION ALTA\n",i+1,presion_neumaticos[i]-1000);
                    }
                else 
                    {
                    system("clear");
                    printf("Error, no se ha realizado la lectura\n");
                    }
            }
        printf("Presiona 0 para elegir otra opcion del menu:");
        scanf("%d",&reset);
    }
    return 0;
}


///Agregar 3 tipos de auto
