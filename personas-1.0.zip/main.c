#include <string.h>
#include <stdio.h>
struct Persona {
    char nombre[50];
    int edad;
    float altura;
};

int main()
{
    //modificar
    int i;
    struct Persona persona1[5];
    for(i=0;i<=4;i++){
    system("clear");
    printf("Nombre persona %d:\n",i+1);
    scanf("%s",persona1[i].nombre);
    printf("Edad persona %d:\n",i+1);
    scanf("%d",&persona1[i].edad);
    printf("Altura persona %d:\n",i+1);
    scanf("%f",&persona1[i].altura);
    
    }

    //imprimir
    system("clear");
    for(i=0;i<=4;i++)
    printf("Nombre: %s\nEdad: %d\nAltura:%.2f\n\n",persona1[i].nombre,persona1[i].edad,persona1[i].altura);

    return 0;
}
