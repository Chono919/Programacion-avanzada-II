//FUNCIÓNES 19/05/2023
#include <stdio.h>
#define size 2
void funcion(char txt[10],int x);

void funcion(char txt[10],int x)
    {
    printf("\t\t%s\n",txt);
    printf("El tamaño en bytes de una variable %s es: %d\n",txt,x);
    printf("El tamaño en bits de una variable %s es: %d\n",txt,(x*8));
    printf("El tamaño en nibbles de una variable %s es: %d\n\n",txt,(x*2));
    }

int main()
{
    char c;
    int x;
    double y;
    int Arreglo[size];
    system("clear");
    printf("\t     PRACTICA 1\n\tPROGRAMACION AVANZADA II\n\tRODRIGO HEREDIA TALAVERA\n\n");
    funcion("CHAR",sizeof(c));
    funcion("ENTERO",sizeof(x));
    funcion("DOUBLE",sizeof(y));
    funcion("ARREGLO",sizeof(Arreglo));

    return 0;
}
